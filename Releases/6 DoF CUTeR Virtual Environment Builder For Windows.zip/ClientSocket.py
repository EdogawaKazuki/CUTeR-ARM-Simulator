class ClientSocket:
    sock = None
    address = None
    host = "0.0.0.0"
    port = 22000
    max_length = 65000

